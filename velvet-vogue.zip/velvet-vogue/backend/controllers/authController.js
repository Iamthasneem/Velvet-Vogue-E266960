const User = require('../models/User');

exports.register = (req, res) => {
    const { username, email, password } = req.body;

    if (!username || !email || !password) {
        return res.status(400).json({ message: 'All fields are required' });
    }

    const existingUser = User.findByEmail(email) || User.findByUsername(username);
    if (existingUser) {
        return res.status(409).json({ message: 'User already exists' });
    }

    // In a real app, hash password here
    const newUser = User.create({ username, email, password, role: 'customer' });

    // Remove password from response
    const { password: _, ...userWithoutPassword } = newUser;
    res.status(201).json({ message: 'User registered successfully', user: userWithoutPassword });
};

exports.login = (req, res) => {
    const { email, password } = req.body;

    const user = User.findByEmail(email);
    if (!user || user.password !== password) {
        return res.status(401).json({ message: 'Invalid credentials' });
    }

    // In a real app, generate JWT here
    const { password: _, ...userWithoutPassword } = user;
    res.json({ message: 'Login successful', user: userWithoutPassword, token: 'mock-jwt-token-123' });
};
