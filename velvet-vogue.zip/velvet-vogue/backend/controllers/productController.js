const Product = require('../models/Product');

exports.getAllProducts = (req, res) => {
    const category = req.query.category;
    if (category) {
        const products = Product.findByCategory(category);
        return res.json(products);
    }
    const products = Product.getAll();
    res.json(products);
};

exports.getProductById = (req, res) => {
    const id = parseInt(req.params.id);
    const product = Product.findById(id);
    if (product) {
        res.json(product);
    } else {
        res.status(404).json({ message: 'Product not found' });
    }
};

exports.getCategories = (req, res) => {
    const products = Product.getAll();
    const categories = [...new Set(products.map(p => p.category))];
    res.json(categories);
};
