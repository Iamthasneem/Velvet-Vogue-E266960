const fs = require('fs');
const path = require('path');

const dataPath = path.join(__dirname, '../products.json');

class Product {
    static getAll() {
        try {
            const data = fs.readFileSync(dataPath, 'utf8');
            return JSON.parse(data);
        } catch (err) {
            return [];
        }
    }

    static findById(id) {
        const products = this.getAll();
        return products.find(p => p.id === id);
    }

    static findByCategory(category) {
        const products = this.getAll();
        return products.filter(p => p.category === category);
    }
}

module.exports = Product;
