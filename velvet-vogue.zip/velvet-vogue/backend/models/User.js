const fs = require('fs');
const path = require('path');

const dataPath = path.join(__dirname, '../users.json');

class User {
    static getAll() {
        try {
            if (!fs.existsSync(dataPath)) return [];
            const data = fs.readFileSync(dataPath, 'utf8');
            return JSON.parse(data);
        } catch (err) {
            return [];
        }
    }

    static save(users) {
        fs.writeFileSync(dataPath, JSON.stringify(users, null, 2));
    }

    static create(user) {
        const users = this.getAll();
        const newUser = { id: users.length + 1, ...user, created_at: new Date() };
        users.push(newUser);
        this.save(users);
        return newUser;
    }

    static findByEmail(email) {
        const users = this.getAll();
        return users.find(u => u.email === email);
    }

    static findByUsername(username) {
        const users = this.getAll();
        return users.find(u => u.username === username);
    }
}

module.exports = User;
