const fs = require('fs');
const path = require('path');

const products = [
    // Men's Casualwear
    {
        name: "Urban Edge Hoodie",
        category: "Men's Casualwear",
        price: 4500.00,
        image: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&w=400&q=80" // Hoodie
    },
    {
        name: "Classic Denim Jeans",
        category: "Men's Casualwear",
        price: 6000.00,
        image: "https://images.unsplash.com/photo-1542272617-08f08630329e?auto=format&fit=crop&w=400&q=80" // Jeans
    },
    {
        name: "Streetwear Graphic Tee",
        category: "Men's Casualwear",
        price: 2500.00,
        image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=400&q=80" // T-shirt
    },
    {
        name: "Canvas Low-Top Sneakers",
        category: "Men's Casualwear",
        price: 5500.00,
        image: "https://images.unsplash.com/photo-1491553895911-0055eca6402d?auto=format&fit=crop&w=400&q=80" // Sneakers
    },
    {
        name: "Relaxed Fit Cargo Pants",
        category: "Men's Casualwear",
        price: 5000.00,
        image: "https://images.unsplash.com/photo-1517445312882-766d3ce22de9?auto=format&fit=crop&w=400&q=80" // Pants
    },

    // Men's Formal Wear
    {
        name: "Midnight Blue Suit",
        category: "Men's Formal Wear",
        price: 25000.00,
        image: "https://images.unsplash.com/photo-1594938298603-c8148c4729d7?auto=format&fit=crop&w=400&q=80" // Suit
    },
    {
        name: "Crisp White Dress Shirt",
        category: "Men's Formal Wear",
        price: 4000.00,
        image: "https://images.unsplash.com/photo-1620799140408-ed5341cd2431?auto=format&fit=crop&w=400&q=80" // Shirt
    },
    {
        name: "Silk Tie - Burgundy",
        category: "Men's Formal Wear",
        price: 3000.00,
        image: "https://images.unsplash.com/photo-1589756823695-278bc923f962?auto=format&fit=crop&w=400&q=80" // Tie
    },
    {
        name: "Leather Oxford Shoes",
        category: "Men's Formal Wear",
        price: 12000.00,
        image: "https://images.unsplash.com/photo-1614252235316-8c857d38b5f4?auto=format&fit=crop&w=400&q=80" // Shoes
    },
    {
        name: "Charcoal Grey Blazer",
        category: "Men's Formal Wear",
        price: 15000.00,
        image: "https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=400&q=80" // Blazer
    },

    // Women's Casualwear
    {
        name: "Boho Chic Maxi Dress",
        category: "Women's Casualwear",
        price: 7500.00,
        image: "https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?auto=format&fit=crop&w=400&q=80" // Dress
    },
    {
        name: "High-Waist Skinny Jeans",
        category: "Women's Casualwear",
        price: 5500.00,
        image: "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&w=400&q=80" // Jeans
    },
    {
        name: "Cozy Knit Sweater",
        category: "Women's Casualwear",
        price: 4500.00,
        image: "https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&w=400&q=80" // Sweater
    },
    {
        name: "Summer Breeze Top",
        category: "Women's Casualwear",
        price: 3000.00,
        image: "https://images.unsplash.com/photo-1503342394128-c104d54dba01?auto=format&fit=crop&w=400&q=80" // Top
    },
    {
        name: "Leather Strappy Sandals",
        category: "Women's Casualwear",
        price: 4000.00,
        image: "https://images.unsplash.com/photo-1543163521-1bf539c55dd2?auto=format&fit=crop&w=400&q=80" // Sandals
    },

    // Women's Formal Wear
    {
        name: "Elegant Evening Gown",
        category: "Women's Formal Wear",
        price: 30000.00,
        image: "https://images.unsplash.com/photo-1566174053879-31528523f8ae?auto=format&fit=crop&w=400&q=80" // Gown
    },
    {
        name: "Tailored Pencil Skirt",
        category: "Women's Formal Wear",
        price: 5000.00,
        image: "https://images.unsplash.com/photo-1583496661160-fb5886a0aaaa?auto=format&fit=crop&w=400&q=80" // Skirt
    },
    {
        name: "Satin Blouse",
        category: "Women's Formal Wear",
        price: 4500.00,
        image: "https://images.unsplash.com/photo-1604176354204-9268737828e4?auto=format&fit=crop&w=400&q=80" // Blouse
    },
    {
        name: "Classic Stiletto Heels",
        category: "Women's Formal Wear",
        price: 9000.00,
        image: "https://images.unsplash.com/photo-1543163521-1bf539c55dd2?auto=format&fit=crop&w=400&q=80" // Heels
    },
    {
        name: "Velvet Blazer",
        category: "Women's Formal Wear",
        price: 11000.00,
        image: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?auto=format&fit=crop&w=400&q=80" // Blazer
    },

    // Accessories
    {
        name: "Genuine Leather Belt",
        category: "Accessories",
        price: 3500.00,
        image: "https://images.unsplash.com/photo-1624222247344-550fb60583dc?auto=format&fit=crop&w=400&q=80" // Belt
    },
    {
        name: "Minimalist Wristwatch",
        category: "Accessories",
        price: 12000.00,
        image: "https://images.unsplash.com/photo-1524592094714-0f0654e20314?auto=format&fit=crop&w=400&q=80" // Watch
    },
    {
        name: "Aviator Sunglasses",
        category: "Accessories",
        price: 8000.00,
        image: "https://images.unsplash.com/photo-1572635196237-14b3f281503f?auto=format&fit=crop&w=400&q=80" // Sunglasses
    },
    {
        name: "Leather Crossbody Bag",
        category: "Accessories",
        price: 9500.00,
        image: "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=400&q=80" // Bag
    },
    {
        name: "Silk Scarf",
        category: "Accessories",
        price: 2500.00,
        image: "https://images.unsplash.com/photo-1584030373081-f37b7bb4fa8e?auto=format&fit=crop&w=400&q=80" // Scarf
    }
];

const fullProducts = products.map((p, index) => ({
    id: index + 1,
    name: p.name,
    category: p.category,
    price: p.price,
    image: p.image,
    description: `Experience the epitome of style with the ${p.name}. Crafted from premium materials, this item from our ${p.category} collection is designed to provide both comfort and sophistication. Perfect for any occasion, it embodies the Velvet Vogue commitment to quality and modern fashion trends. Available in multiple sizes to ensure the perfect fit.`,
    sizes: ["S", "M", "L", "XL"],
    colors: ["Black", "White", "Navy", "Gold"],
    stock: Math.floor(Math.random() * 50) + 10
}));

const outputPath = path.join(__dirname, 'products.json');
fs.writeFileSync(outputPath, JSON.stringify(fullProducts, null, 2));
console.log(`Generated ${fullProducts.length} products in ${outputPath}`);
