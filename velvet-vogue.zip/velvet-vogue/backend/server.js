const express = require('express');
const path = require('path');
const productRoutes = require('./routes/productRoutes');
const authRoutes = require('./routes/authRoutes');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

// API Routes
app.use('/api', productRoutes);
app.use('/api/auth', authRoutes);

// Mock Checkout Route (Keep simple for now)
app.post('/api/checkout', (req, res) => {
    const { cart, total } = req.body;
    console.log('Processing order:', { cart, total });
    res.json({ success: true, orderId: Math.floor(Math.random() * 10000) });
});

// Serve frontend for any other route
app.get(/(.*)/, (req, res) => {
    res.sendFile(path.join(__dirname, '../public/index.html'));
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
