# Velvet Vogue - E-Commerce Platform

A modern, premium e-commerce website for fashion and accessories, designed for young adults with emphasis on sophisticated design and seamless user experience.

## 📋 Project Information

**Project Name:** Velvet Vogue  
**Type:** Multi-page E-commerce Website  
**Target Audience:** Young adults (18-35 years)  
**Status:** Complete and Ready for Submission

## 🛠️ Technology Stack

### Frontend
- **HTML5** - Semantic markup and structure
- **CSS3** - Custom styling with design system (no frameworks)
- **JavaScript (ES6+)** - Vanilla JavaScript for functionality

### Backend
- **Node.js** - JavaScript runtime environment
- **Express.js v5.2.1** - Web application framework
- **JSON** - File-based storage (development)

### External Services
- **Google Fonts** - Inter & Playfair Display typography
- **Unsplash CDN** - Product images

## 📦 Prerequisites

- Node.js (v14 or higher)
- npm (Node Package Manager)
- Modern web browser (Chrome, Firefox, Safari, Edge)

## �� Installation & Setup

1. Navigate to project directory:
   cd velvet-vogue

2. Install dependencies:
   npm install

3. Start the server:
   node backend/server.js

4. Access the website:
   Open browser at http://localhost:3000

## 📁 Project Structure

velvet-vogue/
├── backend/               # Server-side code
├── public/               # Frontend files (11 HTML pages)
├── documentation/        # Complete documentation (Word file)
├── package.json         # Project dependencies
└── README.md           # This file


