// Admin Dashboard Functionality

// Check admin authentication
document.addEventListener('DOMContentLoaded', () => {
    const adminToken = localStorage.getItem('adminToken');
    if (!adminToken) {
        window.location.href = 'admin-login.html';
        return;
    }

    loadAdminProducts();
    initAdminActions();
});

// Load products in admin dashboard
async function loadAdminProducts() {
    try {
        const res = await fetch('/api/products');
        const products = await res.json();

        const tbody = document.getElementById('product-list');
        if (!tbody) return;

        tbody.innerHTML = products.map(p => `
            <tr>
                <td>${p.id}</td>
                <td>${p.name}</td>
                <td>${p.category}</td>
                <td>LKR ${p.price.toLocaleString()}</td>
                <td>${p.stock}</td>
                <td>
                    <button onclick="editProduct(${p.id})" class="btn" style="padding:0.4rem 0.8rem; margin-right:0.5rem;">Edit</button>
                    <button onclick="deleteProduct(${p.id})" class="btn btn-remove" style="padding:0.4rem 0.8rem;">Delete</button>
                </td>
            </tr>
        `).join('');
    } catch (err) {
        console.error('Error loading products:', err);
    }
}

// Initialize admin actions
function initAdminActions() {
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
            localStorage.removeItem('adminToken');
            window.location.href = 'admin-login.html';
        });
    }
}

// Show section
function showSection(section) {
    document.querySelectorAll('main section').forEach(s => s.style.display = 'none');
    const targetSection = document.getElementById(`${section}-section`);
    if (targetSection) {
        targetSection.style.display = 'block';
    }

    // Update active nav
    document.querySelectorAll('aside nav a').forEach(a => a.classList.remove('active'));
    event.target.classList.add('active');
}

// Open add product modal
function openAddProductModal() {
    const modal = document.getElementById('product-modal');
    if (modal) {
        modal.style.display = 'flex';
        document.getElementById('modal-title').textContent = 'Add New Product';
        document.getElementById('product-form').reset();
        document.getElementById('product-id').value = '';
    }
}

// Close modal
function closeModal() {
    const modal = document.getElementById('product-modal');
    if (modal) {
        modal.style.display = 'none';
    }
}

// Edit product
async function editProduct(id) {
    try {
        const res = await fetch(`/api/products/${id}`);
        const product = await res.json();

        const modal = document.getElementById('product-modal');
        if (modal) {
            modal.style.display = 'flex';
            document.getElementById('modal-title').textContent = 'Edit Product';
            document.getElementById('product-id').value = product.id;
            document.getElementById('product-name').value = product.name;
            document.getElementById('product-price').value = product.price;
            document.getElementById('product-category').value = product.category;
            document.getElementById('product-description').value = product.description;
            document.getElementById('product-image').value = product.image;
            document.getElementById('product-stock').value = product.stock;
        }
    } catch (err) {
        console.error('Error loading product:', err);
        alert('Error loading product details');
    }
}

// Delete product
async function deleteProduct(id) {
    if (!confirm('Are you sure you want to delete this product?')) {
        return;
    }

    try {
        const res = await fetch(`/api/products/${id}`, {
            method: 'DELETE'
        });

        if (res.ok) {
            alert('Product deleted successfully');
            loadAdminProducts();
        } else {
            alert('Error deleting product');
        }
    } catch (err) {
        console.error('Error deleting product:', err);
        alert('Error deleting product');
    }
}

// Save product (add or update)
async function saveProduct(event) {
    event.preventDefault();

    const id = document.getElementById('product-id').value;
    const productData = {
        name: document.getElementById('product-name').value,
        price: parseFloat(document.getElementById('product-price').value),
        category: document.getElementById('product-category').value,
        description: document.getElementById('product-description').value,
        image: document.getElementById('product-image').value,
        stock: parseInt(document.getElementById('product-stock').value),
        sizes: ['S', 'M', 'L', 'XL'],
        colors: ['Black', 'White', 'Navy', 'Gold']
    };

    try {
        let res;
        if (id) {
            // Update existing product
            res = await fetch(`/api/products/${id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ ...productData, id: parseInt(id) })
            });
        } else {
            // Create new product
            res = await fetch('/api/products', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(productData)
            });
        }

        if (res.ok) {
            alert(id ? 'Product updated successfully' : 'Product added successfully');
            closeModal();
            loadAdminProducts();
        } else {
            alert('Error saving product');
        }
    } catch (err) {
        console.error('Error saving product:', err);
        alert('Error saving product');
    }
}

// Initialize form submission
document.getElementById('product-form')?.addEventListener('submit', saveProduct);
