// State
let cart = JSON.parse(localStorage.getItem('cart')) || [];

// DOM Elements
const cartCount = document.getElementById('cart-count');

// Init
document.addEventListener('DOMContentLoaded', () => {
    updateCartCount();

    const path = window.location.pathname;

    if (path.includes('products.html') || path === '/' || path.endsWith('index.html')) {
        loadProducts();
    } else if (path.includes('product-detail.html')) {
        loadProductDetail();
    } else if (path.includes('cart.html')) {
        loadCart();
    }

    checkAuth();
    initScrollAnimations();
    initMobileMenu();
});

function initMobileMenu() {
    const hamburger = document.getElementById('hamburger-btn');
    const mobileMenu = document.getElementById('mobile-menu');
    const closeBtn = document.getElementById('close-menu-btn');

    if (hamburger && mobileMenu) {
        hamburger.addEventListener('click', () => {
            mobileMenu.classList.add('active');
        });
    }

    if (closeBtn && mobileMenu) {
        closeBtn.addEventListener('click', () => {
            mobileMenu.classList.remove('active');
        });

        // Close on overlay click
        mobileMenu.addEventListener('click', (e) => {
            if (e.target === mobileMenu) {
                mobileMenu.classList.remove('active');
            }
        });
    }
}

function initScrollAnimations() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('is-visible');
            }
        });
    }, { threshold: 0.1 });

    document.querySelectorAll('.fade-in-section').forEach(section => {
        observer.observe(section);
    });
}

function checkAuth() {
    const user = JSON.parse(localStorage.getItem('user'));
    const nav = document.querySelector('nav ul');
    const authLink = document.getElementById('auth-link'); // If exists

    // Remove existing auth link if any to avoid duplicates
    const existingAuth = document.getElementById('dynamic-auth-link');
    if (existingAuth) existingAuth.remove();

    const li = document.createElement('li');
    li.id = 'dynamic-auth-link';

    if (user) {
        li.innerHTML = `<a href="profile.html">Profile (${user.username})</a>`;
    } else {
        li.innerHTML = `<a href="login.html">Login</a>`;
    }
    nav.appendChild(li);
}

// Cart Functions
function updateCartCount() {
    if (cartCount) {
        const count = cart.reduce((sum, item) => sum + item.quantity, 0);
        cartCount.textContent = count;
    }
}

function addToCart(product, size, color) {
    const existing = cart.find(item => item.id === product.id && item.size === size && item.color === color);

    if (existing) {
        existing.quantity++;
    } else {
        cart.push({
            id: product.id,
            name: product.name,
            price: product.price,
            image: product.image,
            size: size,
            color: color,
            quantity: 1
        });
    }

    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();
    alert('Added to cart!');
}

function removeFromCart(index) {
    cart.splice(index, 1);
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();
    loadCart(); // Refresh cart page
}

// Expose functions to global scope for inline event handlers
window.addToCart = addToCart;
window.removeFromCart = removeFromCart;

// Product Loading with Advanced Filtering
let allProducts = [];
let currentFilters = {
    search: '',
    category: 'all',
    sizes: [],
    colors: [],
    maxPrice: 35000,
    sort: 'default'
};

async function loadProducts() {
    const grid = document.getElementById('product-grid');
    if (!grid) return;

    try {
        // Load all products
        const res = await fetch('/api/products');
        allProducts = await res.json();

        // Check for URL parameters (e.g., ?category=Men's Casualwear)
        const urlParams = new URLSearchParams(window.location.search);
        const categoryParam = urlParams.get('category');
        
        if (categoryParam) {
            currentFilters.category = categoryParam;
        }

        // Initialize filters
        initializeFilters();
        
        // Update active category button if category was set from URL
        if (categoryParam) {
            document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
            const matchingBtn = document.querySelector(`.filter-btn[data-category="${categoryParam}"]`);
            if (matchingBtn) {
                matchingBtn.classList.add('active');
            }
        }

        // Apply filters and display
        applyFiltersAndDisplay();

    } catch (err) {
        console.error('Error loading products:', err);
        grid.innerHTML = '<p style="text-align:center; width:100%; color:var(--neutral-100);">Error loading products</p>';
    }
}

function initializeFilters() {
    // Search input - auto apply
    const searchInput = document.getElementById('search-input');
    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            currentFilters.search = e.target.value.toLowerCase();
            applyFiltersAndDisplay();
        });
    }

    // Category buttons - auto apply
    const filterBtns = document.querySelectorAll('.filter-btn');
    if (filterBtns.length > 0) {
        filterBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                currentFilters.category = btn.dataset.category;
                applyFiltersAndDisplay();
            });
        });
    }

    // Size checkboxes - store but don't auto-apply
    const sizeFilters = document.querySelectorAll('.size-filter');
    if (sizeFilters.length > 0) {
        sizeFilters.forEach(checkbox => {
            checkbox.addEventListener('change', () => {
                currentFilters.sizes = Array.from(document.querySelectorAll('.size-filter:checked')).map(cb => cb.value);
                // Don't auto-apply, wait for Apply Filters button
            });
        });
    }

    // Color checkboxes - store but don't auto-apply
    const colorFilters = document.querySelectorAll('.color-filter');
    if (colorFilters.length > 0) {
        colorFilters.forEach(checkbox => {
            checkbox.addEventListener('change', () => {
                currentFilters.colors = Array.from(document.querySelectorAll('.color-filter:checked')).map(cb => cb.value);
                // Don't auto-apply, wait for Apply Filters button
            });
        });
    }

    // Price range - update display only, don't auto-apply
    const priceRange = document.getElementById('price-range');
    const maxPriceDisplay = document.getElementById('max-price-display');
    if (priceRange && maxPriceDisplay) {
        priceRange.addEventListener('input', (e) => {
            currentFilters.maxPrice = parseInt(e.target.value);
            maxPriceDisplay.textContent = `LKR ${currentFilters.maxPrice.toLocaleString()}`;
            // Don't auto-apply, wait for Apply Filters button
        });
    }

    // Sort select - auto apply
    const sortSelect = document.getElementById('sort-select');
    if (sortSelect) {
        sortSelect.addEventListener('change', (e) => {
            currentFilters.sort = e.target.value;
            applyFiltersAndDisplay();
        });
    }

    // Apply filters button - NEW
    const applyBtn = document.getElementById('apply-filters');
    if (applyBtn) {
        applyBtn.addEventListener('click', () => {
            applyFiltersAndDisplay();
        });
    }

    // Clear filters button
    const clearBtn = document.getElementById('clear-filters');
    if (clearBtn) {
        clearBtn.addEventListener('click', () => {
            // Reset all filters
            currentFilters = {
                search: '',
                category: 'all',
                sizes: [],
                colors: [],
                maxPrice: 35000,
                sort: 'default'
            };

            // Reset UI
            if (searchInput) searchInput.value = '';
            document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
            const allBtn = document.querySelector('.filter-btn[data-category="all"]');
            if (allBtn) allBtn.classList.add('active');
            document.querySelectorAll('.size-filter, .color-filter').forEach(cb => cb.checked = false);
            if (priceRange && maxPriceDisplay) {
                priceRange.value = 35000;
                maxPriceDisplay.textContent = 'LKR 35,000';
            }
            if (sortSelect) sortSelect.value = 'default';

            applyFiltersAndDisplay();
        });
    }
}

function applyFiltersAndDisplay() {
    let filtered = [...allProducts];

    // Apply search filter
    if (currentFilters.search) {
        filtered = filtered.filter(p =>
            p.name.toLowerCase().includes(currentFilters.search) ||
            p.category.toLowerCase().includes(currentFilters.search) ||
            p.description.toLowerCase().includes(currentFilters.search)
        );
    }

    // Apply category filter
    if (currentFilters.category !== 'all') {
        filtered = filtered.filter(p => p.category === currentFilters.category);
    }

    // Apply size filter
    if (currentFilters.sizes.length > 0) {
        filtered = filtered.filter(p =>
            p.sizes && p.sizes.some(size => currentFilters.sizes.includes(size))
        );
    }

    // Apply color filter
    if (currentFilters.colors.length > 0) {
        filtered = filtered.filter(p =>
            p.colors && p.colors.some(color => currentFilters.colors.includes(color))
        );
    }

    // Apply price filter
    filtered = filtered.filter(p => p.price <= currentFilters.maxPrice);

    // Apply sorting
    switch (currentFilters.sort) {
        case 'price-low':
            filtered.sort((a, b) => a.price - b.price);
            break;
        case 'price-high':
            filtered.sort((a, b) => b.price - a.price);
            break;
        case 'name-az':
            filtered.sort((a, b) => a.name.localeCompare(b.name));
            break;
        case 'name-za':
            filtered.sort((a, b) => b.name.localeCompare(a.name));
            break;
    }

    // Update product count
    const productCount = document.getElementById('product-count');
    if (productCount) {
        productCount.textContent = filtered.length;
    }

    // Display products
    displayProducts(filtered);
}

function displayProducts(products) {
    const grid = document.getElementById('product-grid');
    if (!grid) return;

    if (products.length === 0) {
        grid.innerHTML = '<p style="text-align:center; width:100%; color:var(--neutral-100); padding:3rem;">No products found matching your filters.</p>';
        return;
    }

    grid.innerHTML = products.map(p => `
        <div class="product-card">
            <a href="product-detail.html?id=${p.id}" class="product-image-wrapper">
                <img src="${p.image}" alt="${p.name}" class="product-image">
            </a>
            <div class="product-info">
                <div class="product-category">${p.category}</div>
                <h3 class="product-title"><a href="product-detail.html?id=${p.id}">${p.name}</a></h3>
                <div class="product-price">LKR ${p.price.toLocaleString()}</div>
            </div>
        </div>
    `).join('');
}

async function loadProductDetail() {
    const container = document.getElementById('product-detail-container');
    if (!container) return;

    const urlParams = new URLSearchParams(window.location.search);
    const id = urlParams.get('id');

    if (!id) return;

    try {
        const res = await fetch(`/api/products/${id}`);
        if (!res.ok) throw new Error('Product not found');

        const p = await res.json();

        // Populate HTML
        document.getElementById('detail-image').src = p.image;
        document.getElementById('detail-title').textContent = p.name;
        document.getElementById('detail-price').textContent = `LKR ${p.price.toLocaleString()}`;
        document.getElementById('detail-desc').textContent = p.description;
        document.getElementById('detail-category').textContent = p.category;

        // Populate Selects
        const sizeSelect = document.getElementById('size-select');
        p.sizes.forEach(s => {
            const opt = document.createElement('option');
            opt.value = s;
            opt.textContent = s;
            sizeSelect.appendChild(opt);
        });

        const colorSelect = document.getElementById('color-select');
        p.colors.forEach(c => {
            const opt = document.createElement('option');
            opt.value = c;
            opt.textContent = c;
            colorSelect.appendChild(opt);
        });

        // Add to Cart Listener
        document.getElementById('add-to-cart-btn').onclick = () => {
            const size = sizeSelect.value;
            const color = colorSelect.value;
            addToCart(p, size, color);
        };

    } catch (err) {
        container.innerHTML = '<h2>Product not found</h2>';
    }
}

function updateQuantity(index, delta) {
    if (cart[index]) {
        cart[index].quantity += delta;
        if (cart[index].quantity < 1) {
            cart[index].quantity = 1; // Minimum quantity is 1
        }
        localStorage.setItem('cart', JSON.stringify(cart));
        updateCartCount();
        loadCart(); // Refresh cart display
    }
}

// Expose to global scope
window.updateQuantity = updateQuantity;

function loadCart() {
    const container = document.getElementById('cart-items');
    const totalEl = document.getElementById('cart-total-amount');
    const emptyMessage = document.getElementById('empty-cart-message');
    const cartContent = document.getElementById('cart-content');

    if (!container) return;

    if (cart.length === 0) {
        if (emptyMessage) emptyMessage.style.display = 'block';
        if (cartContent) cartContent.style.display = 'none';
        return;
    }

    if (emptyMessage) emptyMessage.style.display = 'none';
    if (cartContent) cartContent.style.display = 'block';

    let total = 0;

    container.innerHTML = cart.map((item, index) => {
        const itemTotal = item.price * item.quantity;
        total += itemTotal;
        return `
            <tr>
                <td>
                    <div style="display:flex; align-items:center; gap:1rem;">
                        <img src="${item.image}" width="50" alt="${item.name}">
                        <div>
                            <div>${item.name}</div>
                            <small>${item.size} / ${item.color}</small>
                        </div>
                    </div>
                </td>
                <td>LKR ${item.price.toLocaleString()}</td>
                <td>
                    <div class="quantity-controls">
                        <button onclick="updateQuantity(${index}, -1)" class="qty-btn" aria-label="Decrease quantity">−</button>
                        <span class="qty-display">${item.quantity}</span>
                        <button onclick="updateQuantity(${index}, 1)" class="qty-btn" aria-label="Increase quantity">+</button>
                    </div>
                </td>
                <td>LKR ${itemTotal.toLocaleString()}</td>
                <td><button onclick="removeFromCart(${index})" class="btn btn-remove">Remove</button></td>
            </tr>
        `;
    }).join('');

    totalEl.textContent = `LKR ${total.toLocaleString()}`;

    const checkoutBtn = document.getElementById('checkout-btn');
    if (checkoutBtn) {
        checkoutBtn.onclick = () => {
            window.location.href = 'checkout.html';
        };
    }
}
